<?php 

include "../function.php";
$id = $_GET['id'];

query("DELETE FROM tb_produk WHERE id_produk='$id'");

$_SESSION['notif'] = "<div>
                                    <span class='d-inline-block alert alert-success'>
                                       Berhasil menghapus produk
                                    </span>
                                  </div>";
                header('Location: produk.php');
        
            die;


 ?>