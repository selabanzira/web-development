<?php session_start();
	date_default_timezone_set('Asia/Jakarta');
	//error_reporting(1);
	$host	= "localhost";
	$user	= "root";
	$pass	= "";
	$db		= "aplikasi_toko_sela_banzira";
	$koneksi = mysqli_connect($host, $user, $pass, $db);

	function query($sql){
		global $koneksi;
		$data = mysqli_query($koneksi, $sql);
		return $data;
	}

	function hitung($sql){
		$row = mysqli_num_rows($sql);
		return $row;
	}

	function angka($str){
		$string = preg_replace("/[^0-9]/","",$str);
		return $string;
	}
	function rupiah($angka){
	
	$hasil_rupiah = "Rp " . number_format($angka,0,',','.');
	return $hasil_rupiah;
	}

	
	$time = time();


$id_website = 1;

$d = query("SELECT * FROM tb_website WHERE id_website='$id_website'");
$data = mysqli_fetch_object($d);

$total = $data->total + 1;
query("UPDATE tb_website SET total='$total'");



 ?>